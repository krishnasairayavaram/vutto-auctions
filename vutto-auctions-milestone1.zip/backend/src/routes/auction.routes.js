import { Router } from 'express';
import Auction from '../models/Auction.js';
import Bid from '../models/Bid.js';
import { requireAuth, requireAdmin } from '../middleware/auth.js';
import { getIO } from '../socket.js';

const router = Router();

router.get('/', async (req, res, next) => {
  try {
    const filter = req.query.status ? { status: req.query.status } : { status: { $ne: 'cancelled' } };
    const auctions = await Auction.find(filter).sort({ endsAt: 1 }).limit(100).populate('currentBidder', 'name');
    res.json({ auctions });
  } catch (error) { next(error); }
});

router.get('/:id', async (req, res, next) => {
  try {
    const auction = await Auction.findById(req.params.id).populate('currentBidder', 'name');
    if (!auction) return res.status(404).json({ message: 'Auction not found' });
    const bids = await Bid.find({ auction: auction._id }).sort({ amount: -1, createdAt: -1 }).limit(20).populate('bidder', 'name');
    res.json({ auction, bids });
  } catch (error) {
    if (error.name === 'CastError') return res.status(404).json({ message: 'Auction not found' });
    next(error);
  }
});

router.post('/', requireAuth, requireAdmin, async (req, res, next) => {
  try {
    const { title, description, make, model, year, mileageKm, imageUrl, startingPrice, minIncrement, startsAt, endsAt } = req.body;
    const start = new Date(startsAt);
    const end = new Date(endsAt);
    const price = Number(startingPrice);
    if (!title || !description || !make || !model) return res.status(400).json({ message: 'Title, description, make, and model are required' });
    if (!Number.isFinite(price) || price < 1) return res.status(400).json({ message: 'Starting price must be a positive number' });
    if (!Number.isFinite(start.getTime()) || !Number.isFinite(end.getTime()) || end <= start) {
      return res.status(400).json({ message: 'Auction end time must be after start time' });
    }
    const auction = await Auction.create({
      title, description, make, model, year: Number(year), mileageKm: Number(mileageKm),
      imageUrl: imageUrl || '', startingPrice: price, currentBid: price,
      minIncrement: Number(minIncrement || 500), startsAt: start, endsAt: end,
      status: start > new Date() ? 'scheduled' : (end > new Date() ? 'live' : 'ended'),
      createdBy: req.user._id
    });
    res.status(201).json({ auction });
  } catch (error) { next(error); }
});

router.post('/:id/bids', requireAuth, async (req, res, next) => {
  try {
    const amount = Number(req.body.amount);
    if (!Number.isSafeInteger(amount) || amount < 1) return res.status(400).json({ message: 'Bid amount must be a positive whole number' });

    const current = await Auction.findById(req.params.id);
    if (!current) return res.status(404).json({ message: 'Auction not found' });
    if (String(current.createdBy) === String(req.user._id)) return res.status(403).json({ message: 'You cannot bid on your own auction' });

    const now = new Date();
    if (current.status !== 'live' || current.startsAt > now || current.endsAt <= now) {
      return res.status(409).json({ message: 'This auction is not currently accepting bids' });
    }
    const minimum = current.currentBid + current.minIncrement;
    if (amount < minimum) return res.status(400).json({ message: `Your bid must be at least ₹${minimum.toLocaleString('en-IN')}` });

    // Conditional single-document update: concurrent bids cannot both overwrite a higher current bid.
    const updated = await Auction.findOneAndUpdate({
      _id: current._id, status: 'live', startsAt: { $lte: now }, endsAt: { $gt: now },
      currentBid: { $lte: amount - current.minIncrement }
    }, { $set: { currentBid: amount, currentBidder: req.user._id } }, { new: true });

    if (!updated) return res.status(409).json({ message: 'Another bid was accepted first. Refresh and try again.' });

    // Follow-up milestone: make bid history and auction update transaction-safe together.
    await Bid.create({ auction: updated._id, bidder: req.user._id, amount });
    const payload = { auctionId: updated._id.toString(), currentBid: updated.currentBid, bidder: { id: req.user._id.toString(), name: req.user.name } };
    getIO()?.to(`auction:${updated._id}`).emit('bid:updated', payload);
    res.status(201).json({ message: 'Bid placed successfully', auction: updated, bid: payload });
  } catch (error) { next(error); }
});

export default router;
