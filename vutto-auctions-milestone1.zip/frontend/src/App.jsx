import { useEffect, useState } from 'react';
import { Gavel, Bike, Search, ShieldCheck, Clock3, ArrowUpRight, LogOut, LogIn, Plus, Gauge, CalendarDays } from 'lucide-react';
import { api } from './api';

const money = (n) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n || 0);
const demoBikes = [
  { _id: 'demo1', title: 'Royal Enfield Continental GT 650', make: 'Royal Enfield', model: 'Continental GT 650', year: 2023, mileageKm: 4200, currentBid: 218000, minIncrement: 1000, status: 'live', endsAt: new Date(Date.now() + 1000 * 60 * 42).toISOString(), imageUrl: '' },
  { _id: 'demo2', title: 'KTM Duke 390', make: 'KTM', model: 'Duke 390', year: 2022, mileageKm: 7800, currentBid: 176000, minIncrement: 1000, status: 'live', endsAt: new Date(Date.now() + 1000 * 60 * 95).toISOString(), imageUrl: '' },
  { _id: 'demo3', title: 'Honda CB350 RS', make: 'Honda', model: 'CB350 RS', year: 2023, mileageKm: 3600, currentBid: 164000, minIncrement: 500, status: 'live', endsAt: new Date(Date.now() + 1000 * 60 * 140).toISOString(), imageUrl: '' }
];

export default function App() {
  const [auctions, setAuctions] = useState([]);
  const [user, setUser] = useState(() => {
    try { return JSON.parse(localStorage.getItem('vutto_user') || 'null'); } catch { return null; }
  });
  const [token, setToken] = useState(() => localStorage.getItem('vutto_token') || '');
  const [mode, setMode] = useState('login');
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [notice, setNotice] = useState('');
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState('');
  const [showAuth, setShowAuth] = useState(false);
  const [showCreate, setShowCreate] = useState(false);
  const [newAuction, setNewAuction] = useState({ title: '', description: '', make: '', model: '', year: '2022', mileageKm: '5000', startingPrice: '50000', minIncrement: '500', startsAt: '', endsAt: '' });

  async function loadAuctions() {
    try {
      const { data } = await api.get('/auctions');
      setAuctions(data.auctions || []);
    } catch {
      setAuctions([]);
    }
  }
  useEffect(() => { loadAuctions(); }, []);

  async function submitAuth(e) {
    e.preventDefault(); setLoading(true); setNotice('');
    try {
      const { data } = await api.post(`/auth/${mode === 'register' ? 'register' : 'login'}`, form);
      localStorage.setItem('vutto_token', data.token);
      localStorage.setItem('vutto_user', JSON.stringify(data.user));
      setToken(data.token); setUser(data.user); setShowAuth(false);
      setNotice(`Welcome${data.user.name ? `, ${data.user.name}` : ''}!`);
    } catch (error) { setNotice(error.response?.data?.message || 'Could not connect to the API. Check that the backend is running.'); }
    finally { setLoading(false); }
  }
  function logout() {
    localStorage.removeItem('vutto_token'); localStorage.removeItem('vutto_user');
    setToken(''); setUser(null); setNotice('You have signed out.');
  }
  async function createAuction(e) {
    e.preventDefault(); setLoading(true); setNotice('');
    try {
      await api.post('/auctions', { ...newAuction, year: Number(newAuction.year), mileageKm: Number(newAuction.mileageKm), startingPrice: Number(newAuction.startingPrice), minIncrement: Number(newAuction.minIncrement), startsAt: new Date(newAuction.startsAt).toISOString(), endsAt: new Date(newAuction.endsAt).toISOString() });
      setShowCreate(false); setNotice('Auction created.'); await loadAuctions();
    } catch (error) { setNotice(error.response?.data?.message || 'Could not create auction. Admin access is required.'); }
    finally { setLoading(false); }
  }

  const visible = auctions.filter(a => `${a.title} ${a.make} ${a.model}`.toLowerCase().includes(search.toLowerCase()));
  const cards = auctions.length ? visible : demoBikes.filter(a => `${a.title} ${a.make} ${a.model}`.toLowerCase().includes(search.toLowerCase()));

  return <div className="app-shell">
    <header className="topbar">
      <a className="brand" href="#"><span className="brand-icon"><Bike size={22}/></span><span>vutto<span className="brand-light">.auctions</span></span></a>
      <nav className="nav-links"><a href="#auctions">Explore auctions</a><a href="#how">How it works</a></nav>
      <div className="nav-actions">
        {user?.role === 'admin' && <button className="button button-outline compact" onClick={() => setShowCreate(true)}><Plus size={16}/> Add auction</button>}
        {user ? <button className="avatar-button" title="Sign out" onClick={logout}><span className="avatar">{user.name?.[0]?.toUpperCase() || 'U'}</span><span className="hide-mobile">{user.name?.split(' ')[0]}</span><LogOut size={15}/></button> : <button className="button button-dark compact" onClick={() => { setShowAuth(true); setMode('login'); }}><LogIn size={16}/> Sign in</button>}
      </div>
    </header>

    <main>
      <section className="hero">
        <div className="hero-copy">
          <div className="eyebrow"><span className="live-dot"/> THE NEXT RIDE STARTS HERE</div>
          <h1>Find your ride.<br/><span>Win the bid.</span></h1>
          <p>A better way to discover exceptional motorcycles. Follow live auctions, place your bid, and ride home with something special.</p>
          <div className="hero-actions"><a className="button button-lime" href="#auctions">Explore live auctions <ArrowUpRight size={17}/></a><a className="text-link" href="#how">How it works <span>→</span></a></div>
          <div className="hero-proof"><div className="proof-avatars"><i>R</i><i>K</i><i>A</i></div><span>Built for riders, by riders</span><span className="proof-sep">·</span><span><ShieldCheck size={14}/> Secure bidding</span></div>
        </div>
        <div className="hero-art">
          <div className="art-grid"></div><div className="art-label">RIDE DIFFERENT <span>↗</span></div>
          <div className="bike-emoji" aria-label="Motorcycle illustration">🏍️</div>
          <div className="art-bottom"><div><small>THE AUCTION EDIT</small><strong>Machines with a story.</strong></div><span className="art-circle"><ArrowUpRight size={22}/></span></div>
          <div className="art-tag">01 / DISCOVER</div>
        </div>
      </section>

      <section className="stats-strip">
        <div><strong>Transparent</strong><span>Clear current bids</span></div><div><strong>Real-time</strong><span>Live auction updates</span></div><div><strong>Rider-first</strong><span>Made for the community</span></div>
      </section>

      <section className="auction-section" id="auctions">
        <div className="section-heading"><div><div className="eyebrow muted">YOUR NEXT OBSESSION</div><h2>Auctions worth chasing<span>.</span></h2><p>Find the machine that makes you look back after parking.</p></div><label className="searchbox"><Search size={18}/><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search bikes, brands..." /></label></div>
        {notice && <div className="notice" role="status">{notice}<button onClick={() => setNotice('')}>×</button></div>}
        {!auctions.length && <div className="demo-note">Preview mode · Connect the backend and add auctions to show live listings.</div>}
        <div className="auction-grid">{cards.map((a, i) => <article className="auction-card" key={a._id}>
          <div className={`bike-visual bike-visual-${i % 3}`}><div className="card-topline"><span className="status-pill"><span className="live-dot"/>{a.status === 'live' ? 'LIVE AUCTION' : a.status?.toUpperCase()}</span><button className="save-button" title="Save listing" onClick={() => setNotice('Watchlist will be added in the next milestone.')}>♡</button></div>
            {a.imageUrl ? <img src={a.imageUrl} alt={a.title} /> : <div className="bike-symbol"><Bike size={82} strokeWidth={1.15}/></div>}
            <span className="bike-year">{a.year}</span>
          </div>
          <div className="card-content"><div className="bike-category">{a.make || 'MOTORCYCLE'} <span>·</span> {a.mileageKm?.toLocaleString('en-IN') || '—'} KM</div><h3>{a.title}</h3><div className="bid-row"><div><span className="field-label">CURRENT BID</span><strong>{money(a.currentBid)}</strong></div><div className="time-left"><Clock3 size={15}/><span>{a.status === 'live' ? 'Live now' : a.status}</span></div></div><button className="bid-button" onClick={() => { if (!token) { setShowAuth(true); setMode('login'); setNotice('Sign in to participate in an auction.'); } else setNotice('Auction detail and bidding UI are coming in Milestone 2.'); }}>View auction <ArrowUpRight size={16}/></button></div>
        </article>)}</div>
        {cards.length === 0 && <div className="empty-state">No auctions match your search. Try another bike or brand.</div>}
      </section>

      <section className="how-section" id="how"><div><div className="eyebrow muted">SIMPLE BY DESIGN</div><h2>Your next ride in <span>three steps.</span></h2></div><div className="how-grid"><div><span className="step-no">01</span><Search/><h3>Discover</h3><p>Explore motorcycles and review their details before you bid.</p></div><div><span className="step-no">02</span><Gavel/><h3>Place your bid</h3><p>Make a valid bid and follow the action as it happens.</p></div><div><span className="step-no">03</span><Bike/><h3>Ride away</h3><p>Track the result and see who wins when the auction closes.</p></div></div></section>
    </main>
    <footer><a className="brand footer-brand" href="#"><span className="brand-icon"><Bike size={19}/></span><span>vutto<span className="brand-light">.auctions</span></span></a><span>Built with care for the next great ride.</span><span>© 2026 Vutto Auctions · Assignment project</span></footer>

    {showAuth && <div className="modal-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) setShowAuth(false); }}><section className="modal"><button className="modal-close" onClick={() => setShowAuth(false)}>×</button><div className="modal-mark"><Bike size={24}/></div><div className="eyebrow muted">{mode === 'register' ? 'JOIN THE COMMUNITY' : 'WELCOME BACK'}</div><h2>{mode === 'register' ? 'Create your account' : 'Sign in to Vutto'}</h2><p>{mode === 'register' ? 'Your next ride is waiting.' : 'Pick up where your next ride begins.'}</p><form onSubmit={submitAuth}>{mode === 'register' && <label>Full name<input required minLength="2" value={form.name} onChange={e => setForm({...form, name:e.target.value})} placeholder="Your name"/></label>}<label>Email address<input type="email" required value={form.email} onChange={e => setForm({...form,email:e.target.value})} placeholder="you@example.com"/></label><label>Password<input type="password" required minLength="8" value={form.password} onChange={e => setForm({...form,password:e.target.value})} placeholder="At least 8 characters"/></label><button className="button button-lime full" disabled={loading}>{loading ? 'Please wait…' : mode === 'register' ? 'Create account' : 'Sign in'} <ArrowUpRight size={16}/></button></form><div className="switch-auth">{mode === 'register' ? 'Already have an account?' : 'New to Vutto?'} <button onClick={() => setMode(mode === 'register' ? 'login' : 'register')}>{mode === 'register' ? 'Sign in' : 'Create account'}</button></div></section></div>}

    {showCreate && <div className="modal-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) setShowCreate(false); }}><section className="modal create-modal"><button className="modal-close" onClick={() => setShowCreate(false)}>×</button><div className="eyebrow muted">ADMIN CONSOLE</div><h2>Create an auction</h2><form onSubmit={createAuction}><label>Listing title<input required value={newAuction.title} onChange={e=>setNewAuction({...newAuction,title:e.target.value})}/></label><div className="form-two"><label>Make<input required value={newAuction.make} onChange={e=>setNewAuction({...newAuction,make:e.target.value})}/></label><label>Model<input required value={newAuction.model} onChange={e=>setNewAuction({...newAuction,model:e.target.value})}/></label></div><div className="form-two"><label>Year<input type="number" required value={newAuction.year} onChange={e=>setNewAuction({...newAuction,year:e.target.value})}/></label><label>Mileage (km)<input type="number" required value={newAuction.mileageKm} onChange={e=>setNewAuction({...newAuction,mileageKm:e.target.value})}/></label></div><label>Description<textarea required value={newAuction.description} onChange={e=>setNewAuction({...newAuction,description:e.target.value})}/></label><div className="form-two"><label>Starting price (₹)<input type="number" min="1" required value={newAuction.startingPrice} onChange={e=>setNewAuction({...newAuction,startingPrice:e.target.value})}/></label><label>Minimum increment (₹)<input type="number" min="1" required value={newAuction.minIncrement} onChange={e=>setNewAuction({...newAuction,minIncrement:e.target.value})}/></label></div><div className="form-two"><label>Starts at<input type="datetime-local" required value={newAuction.startsAt} onChange={e=>setNewAuction({...newAuction,startsAt:e.target.value})}/></label><label>Ends at<input type="datetime-local" required value={newAuction.endsAt} onChange={e=>setNewAuction({...newAuction,endsAt:e.target.value})}/></label></div><button className="button button-lime full" disabled={loading}>{loading ? 'Creating…' : 'Create auction'} <ArrowUpRight size={16}/></button></form></section></div>}
  </div>;
}
